// content.js
chrome.runtime.onMessage.addListener(function(request) {
    if (request.type === 'EXTENSION_ID') {
        window.postMessage({
            type: 'EXTENSION_ID_FROM_EXTENSION',
            id: request.id
        }, '*');
    }
});

// Auch beim Laden senden
window.addEventListener('load', function() {
    setTimeout(function() {
        window.postMessage({
            type: 'EXTENSION_ID_FROM_EXTENSION',
            id: chrome.runtime.id
        }, '*');
    }, 500);
});