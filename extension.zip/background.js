// background.js
let blocklist = [];
let timeLimits = {};
let timeWindows = {};
let usageToday = {};
let globalBlocking = true;

let stats = {
    blockedCount: 0,
    today: new Date().toDateString()
};

chrome.storage.local.get([
    'blocklist', 'timeLimits', 'timeWindows', 'usageToday', 'globalBlocking', 'stats'
], function(result) {
    if (result.blocklist) blocklist = result.blocklist;
    if (result.timeLimits) timeLimits = result.timeLimits;
    if (result.timeWindows) timeWindows = result.timeWindows;
    if (result.usageToday) usageToday = result.usageToday;
    if (result.globalBlocking !== undefined) globalBlocking = result.globalBlocking;
    if (result.stats) stats = result.stats;
    
    checkDayReset();
    startUsageTracking();
});

chrome.webNavigation.onBeforeNavigate.addListener(function(details) {
    if (details.frameId !== 0) return;
    if (!globalBlocking) return;
    
    try {
        const url = new URL(details.url);
        const hostname = url.hostname.replace('www.', '');
        
        for (let blocked of blocklist) {
            if (hostname.includes(blocked)) {
                if (isSiteAllowed(blocked)) return;
                
                chrome.tabs.update(details.tabId, {
                    url: chrome.runtime.getURL('blocked.html') + '?site=' + encodeURIComponent(blocked)
                });
                
                stats.blockedCount++;
                chrome.storage.local.set({stats: stats});
                break;
            }
        }
    } catch (e) {}
});

function isSiteAllowed(site) {
    if (timeWindows[site]) {
        const now = new Date();
        const currentTime = `${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')}`;
        if (currentTime < timeWindows[site].start || currentTime > timeWindows[site].end) {
            return false;
        }
    }
    
    if (timeLimits[site] && usageToday[site] >= timeLimits[site]) {
        return false;
    }
    
    return true;
}

function startUsageTracking() {
    setInterval(function() {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            if (tabs.length === 0) return;
            
            try {
                const url = new URL(tabs[0].url);
                const hostname = url.hostname.replace('www.', '');
                
                for (let site of blocklist) {
                    if (hostname.includes(site)) {
                        usageToday[site] = (usageToday[site] || 0) + 1;
                        chrome.storage.local.set({usageToday: usageToday});
                        break;
                    }
                }
            } catch (e) {}
        });
    }, 60000);
}

chrome.runtime.onMessageExternal.addListener(handleMessage);
chrome.runtime.onMessage.addListener(handleMessage);

function handleMessage(request, sender, sendResponse) {
    switch(request.type) {
        case 'ping':
            sendResponse({success: true, id: chrome.runtime.id});
            break;
        case 'updateBlocklist':
            blocklist = request.sites || [];
            chrome.storage.local.set({blocklist: blocklist});
            sendResponse({success: true});
            break;
        case 'setTimeLimit':
            timeLimits[request.site] = request.minutes;
            chrome.storage.local.set({timeLimits: timeLimits});
            sendResponse({success: true});
            break;
        case 'setTimeWindow':
            timeWindows[request.site] = {start: request.start, end: request.end};
            chrome.storage.local.set({timeWindows: timeWindows});
            sendResponse({success: true});
            break;
        case 'removeTimeLimit':
            delete timeLimits[request.site];
            chrome.storage.local.set({timeLimits: timeLimits});
            sendResponse({success: true});
            break;
        case 'removeTimeWindow':
            delete timeWindows[request.site];
            chrome.storage.local.set({timeWindows: timeWindows});
            sendResponse({success: true});
            break;
        case 'getData':
            sendResponse({
                sites: blocklist,
                timeLimits: timeLimits,
                timeWindows: timeWindows,
                usageToday: usageToday,
                globalBlocking: globalBlocking,
                stats: stats
            });
            break;
        case 'toggleGlobal':
            globalBlocking = !globalBlocking;
            chrome.storage.local.set({globalBlocking: globalBlocking});
            sendResponse({success: true, globalBlocking: globalBlocking});
            break;
    }
    return true;
}

function checkDayReset() {
    const today = new Date().toDateString();
    if (stats.today !== today) {
        stats = {blockedCount: 0, today: today};
        usageToday = {};
        chrome.storage.local.set({stats: stats, usageToday: usageToday});
    }
}

// ID an Web-App senden wenn sie geladen wird
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
    if (changeInfo.status === 'complete' && tab.url && tab.url.includes('hiackerd.github.io/Lockedin')) {
        chrome.tabs.sendMessage(tabId, {
            type: 'EXTENSION_ID',
            id: chrome.runtime.id
        });
    }
});