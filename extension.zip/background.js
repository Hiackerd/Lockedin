// background.js - Mit Zeitlimits und Zeitfenstern

let blocklist = [];           // ['youtube.com', 'instagram.com']
let timeLimits = {};          // { 'youtube.com': 30 } (Minuten pro Tag)
let timeWindows = {};         // { 'youtube.com': { start: '14:00', end: '16:00' } }
let usageToday = {};          // { 'youtube.com': 15 } (Minuten schon genutzt)
let globalBlocking = true;

let stats = {
    blockedCount: 0,
    today: new Date().toDateString()
};

// Beim Start laden
chrome.storage.local.get(['blocklist', 'timeLimits', 'timeWindows', 'usageToday', 'globalBlocking', 'stats'], function(result) {
    if (result.blocklist) blocklist = result.blocklist;
    if (result.timeLimits) timeLimits = result.timeLimits;
    if (result.timeWindows) timeWindows = result.timeWindows;
    if (result.usageToday) usageToday = result.usageToday;
    if (result.globalBlocking !== undefined) globalBlocking = result.globalBlocking;
    if (result.stats) stats = result.stats;
    
    checkDayReset();
    startUsageTracking();
});

// Navigation blockieren
chrome.webNavigation.onBeforeNavigate.addListener(function(details) {
    if (details.frameId !== 0) return;
    if (!globalBlocking) return;
    
    const url = new URL(details.url);
    const hostname = url.hostname.replace('www.', '');
    
    for (let blocked of blocklist) {
        if (hostname.includes(blocked)) {
            // Prüfen ob Seite aktuell erlaubt ist
            if (isSiteAllowed(blocked)) {
                return; // Erlaubt, nicht blockieren
            }
            
            // Blockieren!
            chrome.tabs.update(details.tabId, {
                url: chrome.runtime.getURL('blocked.html') + '?site=' + encodeURIComponent(blocked)
            });
            
            stats.blockedCount++;
            chrome.storage.local.set({stats: stats});
            break;
        }
    }
});

// Prüft ob eine Seite aktuell erlaubt ist
function isSiteAllowed(site) {
    // 1. Zeitfenster prüfen
    if (timeWindows[site]) {
        const now = new Date();
        const currentTime = `${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')}`;
        
        if (currentTime < timeWindows[site].start || currentTime > timeWindows[site].end) {
            return false; // Außerhalb des Zeitfensters → blockieren
        }
    }
    
    // 2. Zeitlimit prüfen
    if (timeLimits[site]) {
        if (usageToday[site] >= timeLimits[site]) {
            return false; // Limit erreicht → blockieren
        }
    }
    
    return true; // Alles ok, Seite erlaubt
}

// Nutzungszeit tracken
function startUsageTracking() {
    setInterval(function() {
        // Aktive Tabs prüfen
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            if (tabs.length === 0) return;
            
            const url = new URL(tabs[0].url);
            const hostname = url.hostname.replace('www.', '');
            
            // Prüfen ob diese Seite in blocklist ist
            for (let site of blocklist) {
                if (hostname.includes(site)) {
                    // Nutzungszeit erhöhen (alle 60 Sekunden)
                    usageToday[site] = (usageToday[site] || 0) + 1;
                    chrome.storage.local.set({usageToday: usageToday});
                    break;
                }
            }
        });
    }, 60000); // Jede Minute
}

// Nachrichten empfangen
chrome.runtime.onMessageExternal.addListener(handleMessage);
chrome.runtime.onMessage.addListener(handleMessage);

function handleMessage(request, sender, sendResponse) {
    switch(request.type) {
        case 'ping':
            sendResponse({success: true});
            break;
            
        case 'updateBlocklist':
            blocklist = request.sites || [];
            chrome.storage.local.set({blocklist: blocklist});
            sendResponse({success: true});
            break;
            
        case 'setTimeLimit':
            // request: { site: 'youtube.com', minutes: 30 }
            timeLimits[request.site] = request.minutes;
            chrome.storage.local.set({timeLimits: timeLimits});
            sendResponse({success: true});
            break;
            
        case 'setTimeWindow':
            // request: { site: 'youtube.com', start: '14:00', end: '16:00' }
            timeWindows[request.site] = {
                start: request.start,
                end: request.end
            };
            chrome.storage.local.set({timeWindows: timeWindows});
            sendResponse({success: true});
            break;
            
        case 'removeTimeLimit':
            delete timeLimits[request.site];
            chrome.storage.local.set({timeLimits: timeLimits});
            sendResponse({success: true});
            break;
            
        case 'removeTimeWindow':
            delete timeWindows[request.site];
            chrome.storage.local.set({timeWindows: timeWindows});
            sendResponse({success: true});
            break;
            
        case 'getData':
            sendResponse({
                sites: blocklist,
                timeLimits: timeLimits,
                timeWindows: timeWindows,
                usageToday: usageToday,
                globalBlocking: globalBlocking,
                stats: stats
            });
            break;
            
        case 'toggleGlobal':
            globalBlocking = !globalBlocking;
            chrome.storage.local.set({globalBlocking: globalBlocking});
            sendResponse({success: true, globalBlocking: globalBlocking});
            break;
    }
    return true;
}

// Tägliche Zurücksetzung
function checkDayReset() {
    const today = new Date().toDateString();
    if (stats.today !== today) {
        stats = {
            blockedCount: 0,
            today: today
        };
        usageToday = {}; // Nutzungszeiten zurücksetzen
        chrome.storage.local.set({
            stats: stats,
            usageToday: usageToday
        });
    }
}