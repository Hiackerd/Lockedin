document.addEventListener('DOMContentLoaded', function() {
    // Elemente
    const openAppBtn = document.getElementById('openApp');
    const toggleBtn = document.getElementById('toggleGlobal');
    const statusEl = document.getElementById('status');
    const blockedCountEl = document.getElementById('blockedCount');
    const sitesCountEl = document.getElementById('sitesCount');
    const blockListEl = document.getElementById('blockList');

    let globalBlocking = true;

    // Daten laden
    chrome.runtime.sendMessage({ type: 'getData' }, function(response) {
        if (response) {
            globalBlocking = response.globalBlocking;
            
            // Status
            statusEl.textContent = globalBlocking ? 'Aktiv' : 'Inaktiv';
            toggleBtn.textContent = globalBlocking ? 'Global deaktivieren' : 'Global aktivieren';
            
            // Stats
            if (response.stats) {
                blockedCountEl.textContent = response.stats.blockedCount || 0;
            }
            
            // Blockierte Seiten
            if (response.sites && response.sites.length > 0) {
                sitesCountEl.textContent = response.sites.length;
                
                let html = '';
                response.sites.slice(0, 5).forEach(site => {
                    html += `<div class="block-item">
                        <span class="block-url">${site}</span>
                    </div>`;
                });
                
                if (response.sites.length > 5) {
                    html += `<div class="block-item">
                        <span class="block-count">+${response.sites.length - 5} weitere</span>
                    </div>`;
                }
                
                blockListEl.innerHTML = html;
            }
        }
    });

    // App öffnen
    openAppBtn.addEventListener('click', function() {
        chrome.tabs.create({ url: "http://localhost:5500/website/index.html" });
    });

    // Global umschalten
    toggleBtn.addEventListener('click', function() {
        chrome.runtime.sendMessage({ 
            type: 'updateBlocklist',
            globalBlocking: !globalBlocking
        }, function() {
            window.close();
        });
    });
});