// popup.js
const id = chrome.runtime.id;
document.getElementById('extensionId').textContent = id;

document.getElementById('copyBtn').addEventListener('click', function() {
    navigator.clipboard.writeText(id).then(function() {
        alert('ID kopiert!');
    });
});